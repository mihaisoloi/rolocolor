/** Automatically generated file. DO NOT MODIFY */
package jp.epson.moverio.bt200.demo.bt200ctrldemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}